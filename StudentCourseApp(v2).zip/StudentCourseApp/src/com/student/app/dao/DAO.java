package com.student.app.dao;

import java.util.List;

import com.student.app.entity.CourseModel;
import com.student.app.entity.StudentDetailsModel;
import com.student.app.entity.StudentModel;

public interface DAO {
	//------------------Student--------------------------
	public List<StudentModel> getStudentModelList();
	public List<StudentDetailsModel> getStudentDetailsModel();
	public StudentModel insertStudent(StudentModel theStudentModel);	//C,U
	public StudentModel getStudentById(int id);							//R
	public void deleteStudent(StudentModel theStudentModel);			//D
	
	//------------------Course----------------------------
	public List<CourseModel> getCourseModelList();
	public CourseModel insertCourse(CourseModel theCourseModel);		//C,U
	public CourseModel getCourseById(int id);							//R
	public void deleteCourse(CourseModel theCourseModel);				//D
	public StudentDetailsModel getStudentDetailsModelById(int sdm_id);
	
} 
