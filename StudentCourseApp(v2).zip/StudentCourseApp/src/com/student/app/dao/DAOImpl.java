package com.student.app.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.student.app.entity.CourseModel;
import com.student.app.entity.StudentDetailsModel;
import com.student.app.entity.StudentModel;

@Repository
public class DAOImpl implements DAO {

	@Autowired
	private SessionFactory sessionFactory;
	

	//----------------------STUDENT RELATED-----------------------------------
	
	// RETRIEVE ALL STRUDENT LIST
	@Override
	public List<StudentModel> getStudentModelList() {
		
		Session currentSession = sessionFactory.getCurrentSession();
		Query<StudentModel> theQuery = currentSession.createQuery("from student", StudentModel.class);
		List<StudentModel> theStudentModel = theQuery.getResultList();
		return theStudentModel;
	}
	
	// RETRIEVE DEPENDENT ENTITY
	@Override
	public List<StudentDetailsModel> getStudentDetailsModel() {
		
		Session currentSession = sessionFactory.getCurrentSession();
		Query<StudentDetailsModel> theQuery = currentSession.createQuery("from student_details", StudentDetailsModel.class);
		List<StudentDetailsModel> theStudentDetailsModel = theQuery.getResultList();
		return theStudentDetailsModel;
	}
	
	
	// INSERT STUDENT [ADD/UPDATE]
	@Override
	public StudentModel insertStudent(StudentModel theStudentModel) {
		
		Session currentSession = sessionFactory.getCurrentSession();
		StudentModel theStudentModelObj = (StudentModel) currentSession.merge(theStudentModel);
		System.out.println(theStudentModel);
		return theStudentModelObj;
	}
	

	// RETRIEVE STUDENT BY ID
	@Override
	public StudentModel getStudentById(int id) {
		
		Session currentSession = sessionFactory.getCurrentSession();
		
		StudentModel theStudentModel = currentSession.get(StudentModel.class, id);				
		return theStudentModel;
	}
	

	// DELETE STUDENT
	@Override
	public void deleteStudent(StudentModel theStudentModel) {
		Session currentSession = sessionFactory.getCurrentSession();
		currentSession.delete(theStudentModel);
	}
	
	
	//------------------------COURSE REALTED ---------------------------------
	
	
	// INSERT COURSE [ADD/UPDATE]
	@Override
	public CourseModel insertCourse(CourseModel theCourseModel) {
		Session currentSession = sessionFactory.getCurrentSession();
		theCourseModel = (CourseModel) currentSession.merge(theCourseModel);
		return theCourseModel;
	}
	
	
	// RETRIEVE COURSE BY ID
	@Override
	public CourseModel getCourseById(int id) {
		Session currentSession = sessionFactory.getCurrentSession();
		CourseModel theCourseModel = currentSession.get(CourseModel.class, id);		
		return theCourseModel;
	}
	
	
	// DELETE COURSE
	@Override
	public void deleteCourse(CourseModel theCourseModel) {
		Session currentSession = sessionFactory.getCurrentSession();
		currentSession.delete(theCourseModel);
	}
	
	
	// GET ALL COURSES LIST
	@Override
	public List<CourseModel> getCourseModelList() {
		Session currentSession = sessionFactory.getCurrentSession();
		Query<CourseModel> theQuery = currentSession.createQuery("from course", CourseModel.class);
		List<CourseModel> theCourseModel = theQuery.getResultList();
		return theCourseModel;
	}
	
	
	// RETRIEVE DEPENDENT CHILD ENTITY
	@Override
	public StudentDetailsModel getStudentDetailsModelById(int sdm_id) {
		Session currentSession = sessionFactory.getCurrentSession();
		StudentDetailsModel theStudentDetailsModel = currentSession.get(StudentDetailsModel.class, sdm_id);	
		return theStudentDetailsModel;
	}
	

	
	

}
