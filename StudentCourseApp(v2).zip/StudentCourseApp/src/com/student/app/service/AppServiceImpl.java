package com.student.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.student.app.dao.DAO;
import com.student.app.entity.CourseModel;
import com.student.app.entity.StudentDetailsModel;
import com.student.app.entity.StudentModel;

@Service
public class AppServiceImpl implements AppService {
	
	
	@Autowired
	private DAO theDAO;			// StudentDAOImpl Object Injected
	
	//---------------------@Transactional----------------------
	// 	@Transactional automates JDBC transaction: 
	//	1. 	Beginning the JDBC Transaction
	//	2.	Performing the CRUD operation
	//	3.	Commit the JDBC Transaction 
	//----------------------------------------------------------
	
	
	//------------------STUDENT RELATED-----------------------
	
	
	// GET THE LIST OF STUDENTS
	@Override
	@Transactional	
	public List<StudentModel> getStudentModelList() {
		return theDAO.getStudentModelList();
	}
	
	// GET THE DEPENDENT ENTITY LIST FOR STUDENTS
	@Override
	@Transactional	
	public List<StudentDetailsModel> getStudentDetailsModel() {
		return theDAO.getStudentDetailsModel();
	}

	// GET DEPENDENT ENTITY BY ID FOR STUDENT
	@Override
	@Transactional
	public StudentDetailsModel getStudentDetailsModelById(int sdm_id) {
		return theDAO.getStudentDetailsModelById(sdm_id);
	}
	
	// INSERT STUDENT [ADD/UPDATE]
	@Override
	@Transactional
	public StudentModel insertStudent(StudentModel theStudentModel) {
		return theDAO.insertStudent(theStudentModel);

	}

	
	// GET SETUDENT BY ID
	@Override
	@Transactional
	public StudentModel getStudentById(int id) {
		return theDAO.getStudentById(id);
	}
	
	
	// DELETE A STUDENT
	@Override
	@Transactional
	public void deleteStudent(StudentModel theStudentModel) {
		theDAO.deleteStudent(theStudentModel);
	}


	
	//----------------------COURSE------------------------------
	
	// INSERT COURSE [ADD/UPDATE]
	@Override
	@Transactional														
	public CourseModel insertCourse(CourseModel theCourseModel) {
		theCourseModel = theDAO.insertCourse(theCourseModel);
		return theCourseModel;
	}
	
	// GET COURSE BY ID
	@Override
	@Transactional
	public CourseModel getCourseById(int id) {
		return theDAO.getCourseById(id);
	}
	
	// DELETE A COURSE
	@Override
	@Transactional
	public void deleteCourse(CourseModel theCourseModel) {
		theDAO.deleteCourse(theCourseModel);
	}
	
	// GET COURSE LIST
	@Override
	@Transactional
	public List<CourseModel> getCourseModelList() {
		return theDAO.getCourseModelList();
	}


	
}






