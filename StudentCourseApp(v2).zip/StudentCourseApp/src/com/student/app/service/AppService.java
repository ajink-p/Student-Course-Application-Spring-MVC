package com.student.app.service;

import java.util.List;

import com.student.app.entity.CourseModel;
import com.student.app.entity.StudentDetailsModel;
import com.student.app.entity.StudentModel;

public interface AppService {
	//----------------service - course-------------
	public List<StudentModel> getStudentModelList();
	public List<StudentDetailsModel> getStudentDetailsModel();
	public StudentModel insertStudent(StudentModel theStudentModel);				//C,U
	StudentModel getStudentById(int id);							//R
	void deleteStudent(StudentModel theStudentModel);				//D
	
	//------------------Service - Course-----------------
	public List<CourseModel> getCourseModelList();
	public CourseModel insertCourse(CourseModel theCourseModel);			//C,U
	public CourseModel getCourseById(int id);						//R
	public void deleteCourse(CourseModel theCourseModel);			//D
//	public boolean enrollCheck(int sid, int cid);
	public StudentDetailsModel getStudentDetailsModelById(int sdm_id);
	





}
