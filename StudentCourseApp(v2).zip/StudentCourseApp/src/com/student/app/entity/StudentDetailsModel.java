package com.student.app.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

//THE DEPENDENT ENTITY
@Entity(name="student_details")
@Table(name="student_details")
public class StudentDetailsModel {	

	@Id
	@GeneratedValue (strategy = GenerationType.IDENTITY)
	@Column
	private int student_id;
	
	@Column
	private String email;
	
	@Column
	private String phone;
	
	@Column
	private String address;


	
	//----------------CONSTRUCTOR--------------------
	
	public StudentDetailsModel() {
		
	}
	

	//-----------------GETTER-SETTER-------------------
	public int getStudent_id() {
		return student_id;
	}
	public void setStudent_id(int student_id) {
		this.student_id = student_id;
	}

	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
}






