package com.student.app.entity;

import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotBlank;


@Entity(name="course")
@Table(name="course")
public class CourseModel {

	
	@Id
	@GeneratedValue (strategy = GenerationType.IDENTITY)
	@Column
	private int course_id;
	
	@NotBlank(message = "*cannot be left blank")
	@Column
	private String course_name;
	
	@NotBlank(message = "*cannot be left blank")
	@Column
	private String course_instructor;
	
	@NotBlank(message = "*cannot be left blank")
	@Column
	private String course_about;
	
	
	
	//-----------------MANY-TO-MANY MAPPING--------------------
	@ManyToMany(fetch=FetchType.EAGER, 
			    cascade={CascadeType.PERSIST,CascadeType.MERGE,
			    		CascadeType.DETACH,CascadeType.REFRESH})	// NO CASCADE delete here
	@JoinTable(name="student_course_join",							// Normal: inside course class, Inverse: the other table in relationship 
			   joinColumns=@JoinColumn(name="course_id"), 			// student_id FK is set in student_course_join 
			   inverseJoinColumns=@JoinColumn(name="student_id")	// course_id FK is set in student_course_join                   
			   )	
	private List<StudentModel> theStudentModelList;
	
	
	//---------------------CONSTRUCTOR-------------------------
	
	public CourseModel() {
	}

	
	//-------------------GETTER-SETTER ------------------------
	public int getCourse_id() {
		return course_id;
	}
	public void setCourse_id(int course_id) {
		this.course_id = course_id;
	}
	
	public String getCourse_name() {
		return course_name;
	}
	public void setCourse_name(String course_name) {
		this.course_name = course_name;
	}
	
	public String getCourse_instructor() {
		return course_instructor;
	}
	public void setCourse_instructor(String course_instructor) {
		this.course_instructor = course_instructor;
	}
	
	public String getCourse_about() {
		return course_about;
	}
	public void setCourse_about(String course_about) {
		this.course_about = course_about;
	}
	
	
	//--------------GETTER-SETTER: THE JOIN TABLE REFERENCE------------------
	
	public List<StudentModel> getTheStudentModelList() {
		return theStudentModelList;
	}
	public void setTheStudentModelList(List<StudentModel> theStudentModelList) {
		this.theStudentModelList = theStudentModelList;
	}
	



	
	
}
