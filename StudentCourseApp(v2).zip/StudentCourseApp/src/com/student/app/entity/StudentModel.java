package com.student.app.entity;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;
import org.hibernate.validator.constraints.NotBlank;



@Entity(name="student")
@Table(name="student")
public class StudentModel {
	
	
	@Id
	@GeneratedValue (strategy = GenerationType.IDENTITY)
	@Column
	private int student_id;
	
	@NotBlank(message = "*cannot be left blank")
	@Pattern(regexp="[a-zA-Z]*", message="*only alphabets allowed")
	@Column
	private String first_name;
	
	@NotBlank(message = "*cannot be left blank")
	@Pattern(regexp="[a-zA-Z]*", message="*only alphabets allowed")
	@Column
	private String last_name;
	


	//------------ONE-TO-ONE MAPPING---------------------
	
	@OneToOne(fetch=FetchType.EAGER,cascade=CascadeType.ALL)
	@JoinColumn(name="student_details_id")					                             										                                                                                                        
	private StudentDetailsModel theStudentDetailsModel;
	

	//------------MANY-TO-MANY---------------------------
	
	@ManyToMany(fetch=FetchType.EAGER, 
				cascade={CascadeType.PERSIST,CascadeType.MERGE,
						CascadeType.DETACH,CascadeType.REFRESH})  	// NO CASCADE delete here 
	@JoinTable(name="student_course_join",							
			   joinColumns=@JoinColumn(name="student_id"), 			// student_id FK is set in student_course_join 
			   inverseJoinColumns=@JoinColumn(name="course_id")		// course_id FK is set in student_course_join                          
			   )
	private List<CourseModel> theCourseModelList;					// so here, 1 StudentModel(OBJ) -->  LIST CourseModel(OBJS)

	
	//--------------Constructor-------------------------
	public StudentModel() {
	}
	

	//-------------SETTER-GETTER-------------------------
	public void setStudent_id(int student_id) {
		this.student_id = student_id;
	}
	public int getStudent_id() {
		return student_id;
	}
	
	public String getFirst_name() {
		return first_name;
	}
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}

	public String getLast_name() {
		return last_name;
	}
	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}
	


	//-------------------SETTER-GETTER : ONE-TO-ONE-----------------------------
	public StudentDetailsModel getTheStudentDetailsModel() {
		return theStudentDetailsModel;
	}
	public void setTheStudentDetailsModel(StudentDetailsModel theStudentDetailsModel) {
		this.theStudentDetailsModel = theStudentDetailsModel;
	}
	

		
	//-------------------SETTER-GETTER : MANY-TO-MANY---------------------------
	public List<CourseModel> getTheCourseModelList() {
		return theCourseModelList;
	}

	public void setTheCourseModelList(List<CourseModel> theCourseModelList) {
		this.theCourseModelList = theCourseModelList;
	}
	
		// MAPPING FOR MANY-TO-MANY : SETS UP LINK OBJ
		public void addCourse(CourseModel theCourseModel) {
			if(theCourseModelList == null) {
				theCourseModelList = new ArrayList<CourseModel>();
			}
			theCourseModelList.add(theCourseModel);
		}
	
	



	
}
