package com.student.app.controller;

import java.util.List;
import java.util.ListIterator;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.student.app.entity.CourseModel;
import com.student.app.entity.StudentDetailsModel;
import com.student.app.entity.StudentModel;
import com.student.app.service.AppService;

@Controller
public class studentController {
	
	@Autowired  
	private AppService theAppService;		
	
	//---------------------------------------------------
	// The HomePage mapping
	
	@RequestMapping("/")					
	ModelAndView homePage() {
		
		ModelAndView mav = new ModelAndView("homePage");
		return mav;
	}
	
	
	//---------------------------------------------------
	// Displays student form for Add/Update 
	
	@RequestMapping("/showStudentForm")		
	ModelAndView showStudentForm() {
		

		StudentModel theStudentModel = new StudentModel();
		StudentDetailsModel theStudentDetailsModel = new StudentDetailsModel();
		
		theStudentModel.setTheStudentDetailsModel(theStudentDetailsModel);
		ModelAndView mav = new ModelAndView("showStudentForm", "theStudentModel", theStudentModel);
		return mav;
	}
	
	
	//---------------------------------------------------
	// Displays list of all students

	@RequestMapping("/showStudentList")		// list all Students
	ModelAndView showStudentList() {
		
		List<StudentModel> theStudentModelList = theAppService.getStudentModelList();
		ModelAndView mav = new ModelAndView("showStudentList","theStudentModelList",theStudentModelList);
		return mav;
	}
	
	
	//---------------------------------------------------
	// Add/Update of students handled here
	
	@PostMapping("/insertStudent")			
	ModelAndView insertStudent(@Valid @ModelAttribute("theStudentModel") StudentModel theStudentModel,                                     
							   BindingResult result) { 
		
		ModelAndView mav;
		if(result.hasErrors()) {
			mav = new ModelAndView("showStudentForm","theStudentModel",theStudentModel);
		}else {
			theAppService.insertStudent(theStudentModel);	
			mav = new ModelAndView("redirect:/showStudentList");
		}
		return mav;
	}
	
	
	//---------------------------------------------------
	// Student Page 
	
	@RequestMapping("/studentPage/{sid}")		
	public ModelAndView studentPage(@PathVariable("sid") int sid){
		

		// One-to-One : (Obj)StudentModel linked to (Obj)StudenDetailsModel via foreign key
		StudentModel theStudentModel = theAppService.getStudentById(sid);					 
		ModelAndView mav = new ModelAndView("showStudentPage", "theStudentModel", theStudentModel);
		
		// Many-to-Many : Here got the enrolled courses from course table via the join table 
		List<CourseModel> theEnrolledCourseModelList  = theStudentModel.getTheCourseModelList();                         
		mav.addObject("theEnrolledCourseModelList", theEnrolledCourseModelList);
		return mav;
	}

	
	//---------------------------------------------------
	// Add your courses page
	@RequestMapping("/addYourCourses/{sid}") 
	public ModelAndView addYourCourses(@PathVariable("sid") int sid) {
		
		ModelAndView mav;
		StudentModel theStudentModel = theAppService.getStudentById(sid);					
		List<CourseModel> theCourseModelList = theAppService.getCourseModelList();    		             
		mav = new ModelAndView("addYourCourses","theCourseModelList",theCourseModelList);
		mav.addObject("theStudentModel", theStudentModel);
		return mav;
	}
	
	
	//---------------------------------------------------
	// Enroll a particular course controller
	
	@RequestMapping("/enrollForACourse/{sid}/{cid}")   
	public ModelAndView enrollForACourse(@PathVariable("sid") int sid,
								   @PathVariable("cid") int cid){
		
		ModelAndView mav;
		StudentModel theStudentModel = theAppService.getStudentById(sid);
		
		//---------------------------
		// Check If Already Enrolled
		//---------------------------
		List<CourseModel> theEnrolledCourseModelList  = theStudentModel.getTheCourseModelList();
		ListIterator<CourseModel> listIterator =  theEnrolledCourseModelList.listIterator();
		while(listIterator.hasNext()) {
			if(listIterator.next().getCourse_id() == cid) {
				mav = new ModelAndView("alreadyEnrolled","sid",sid);		// already enrolled
				return mav;      
			}
		}
		
		//------------------------------
		// If not Enrolled, then Enroll
		//-------------------------------
		CourseModel theCourseModel = theAppService.getCourseById(cid);		// get the course object
		theStudentModel.addCourse(theCourseModel);							// set the join
		theAppService.insertStudent(theStudentModel);
		mav = new ModelAndView("courseAddedSuccessfully");
		return mav;
	} 
	
	
	//---------------------------------------------------
	// Already Enrolled Page
	
	@RequestMapping("/alreadyEnrolled/{sid}")   
	public ModelAndView alreadyEnrolled(@PathVariable("sid") int sid){
		
		ModelAndView mav = new ModelAndView("alreadyEnrolled","sid",sid);
		return mav;
	}
	
	
	//---------------------------------------------------
	// Edit/Update Student Page
	
	@RequestMapping("/editStudent/{sid}")   
	public ModelAndView updateStudentform(@PathVariable("sid") int sid){

		StudentModel theStudentModel = theAppService.getStudentById(sid);	     
		ModelAndView mav = new ModelAndView("showStudentForm","theStudentModel", theStudentModel);		
	    return mav;    
	}  	
	 
	
	//---------------------------------------------------
	// Delete Student
	
	@RequestMapping("/deleteStudent/{id}")   					
	public String deleteStudent(@PathVariable("id") int id){
		
		StudentModel theStudentModel = theAppService.getStudentById(id);
		theAppService.deleteStudent(theStudentModel);
	    return "redirect:/showStudentList";    
	} 
	
}








 