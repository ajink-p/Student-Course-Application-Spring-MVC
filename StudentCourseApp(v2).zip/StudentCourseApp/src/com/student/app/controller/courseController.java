package com.student.app.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.student.app.entity.CourseModel;
import com.student.app.service.AppService;

@Controller
public class courseController {

	@Autowired
	private AppService theAppService; 
	
	//---------------------------------------------------
	// Displays the Course Form for Add/Update
	
	@RequestMapping("/showCourseForm") 
	ModelAndView showCourseForm() {
		
		CourseModel theCourseModel = new CourseModel();
		ModelAndView mav = new ModelAndView("showCourseForm");
		mav.addObject("theCourseModel", theCourseModel);
		return mav;
	}
	
	
	//---------------------------------------------------
	// Displays List of all courses
	
	@RequestMapping("/showCourseList")		
	ModelAndView showCourseList() {
		
		List<CourseModel> theCourseModelList = theAppService.getCourseModelList();
		ModelAndView mav = new ModelAndView("showCourseList","theCourseModelList",theCourseModelList);                  
		return mav;
	}
	
	
	//---------------------------------------------------
	// Course Add/Update handled by this controller
	
	@PostMapping("/insertCourse")			
	ModelAndView insertCourse(@Valid @ModelAttribute("theCourseModel") CourseModel theCourseModel, 
							  BindingResult result) {
		
		ModelAndView mav;
			if(result.hasErrors()) {
				mav = new ModelAndView("showCourseForm","theCourseModel",theCourseModel);	
			}
			else {
				theCourseModel = theAppService.insertCourse(theCourseModel);	
				mav = new ModelAndView("showCoursePage","theCourseModel",theCourseModel);
			}
		return mav;
	}
	
	
	//---------------------------------------------------
	// Populates a particular course and then displays it on a it's own page 
	
	@RequestMapping("/coursePage/{id}")		
	public ModelAndView coursePage(@PathVariable("id") int id){
		
		CourseModel theCourseModel = theAppService.getCourseById(id);
		ModelAndView mav = new ModelAndView("showCoursePage", "theCourseModel", theCourseModel);
		return mav;
	}

	
	//---------------------------------------------------
	// Edit course details handled by this controller
	
	@RequestMapping("/editCourse/{id}")   
	public ModelAndView editCourse(@PathVariable("id") int id){
		
		CourseModel theCourseModel = theAppService.getCourseById(id); 
		ModelAndView mav = new ModelAndView("showCourseForm");
		mav.addObject("theCourseModel", theCourseModel);
	    return mav;    
	}  	
	 
	
	//---------------------------------------------------
	// Delete course handled here
	
	@RequestMapping("/deleteCourse/{id}")   					
	public String deleteCourse(@PathVariable("id") int id){
		
		CourseModel theCourseModel = theAppService.getCourseById(id);
		theAppService.deleteCourse(theCourseModel);
	    return "redirect:/showCourseList";    
	} 

	
}






